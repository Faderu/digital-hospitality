@extends('layouts.app')

@section('header')
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        {{ __('Buat Janji Temu') }}
    </h2>
@endsection

@section('content')
<div class="max-w-4xl mx-auto bg-white shadow-xl rounded-xl overflow-hidden border-t-4 border-teal-600">
    <div class="p-8">
        
        <div class="mb-8 border-b border-gray-100 pb-4">
            <h1 class="text-2xl font-bold text-gray-900">Formulir Pendaftaran Pasien</h1>
            <p class="text-gray-500 mt-1">Isi data berikut untuk menjadwalkan konsultasi dengan dokter.</p>
        </div>

        <form action="{{ route('appointments.store') }}" method="POST">
            @csrf

            <div class="mb-6">
                <label for="poli_id" class="block text-sm font-bold text-gray-700 mb-2">1. Pilih Poliklinik</label>
                <div class="relative">
                    <select name="poli_id" id="poli_id" required class="block w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500 py-3 pl-4 pr-10" onchange="loadDoctors(this.value)">
                        <option value="">-- Silakan Pilih Poli --</option>
                        @foreach($polis as $poli)
                        <option value="{{ $poli->id }}">{{ $poli->name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="mb-6">
                <label for="doctor_id" class="block text-sm font-bold text-gray-700 mb-2">2. Pilih Dokter</label>
                <select name="doctor_id" id="doctor_id" required class="block w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500 py-3 disabled:bg-gray-100 disabled:text-gray-400" onchange="loadSchedules(this.value)" disabled>
                    <option value="">-- Pilih Dokter --</option>
                </select>
            </div>

            <div class="mb-6">
                <label for="schedule_id" class="block text-sm font-bold text-gray-700 mb-2">3. Pilih Jadwal Praktik</label>
                <select name="schedule_id" id="schedule_id" required class="block w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500 py-3 disabled:bg-gray-100 disabled:text-gray-400" disabled>
                    <option value="">-- Pilih Jadwal --</option>
                </select>
                <p class="text-xs text-gray-500 mt-1">*Pastikan memilih jadwal yang sesuai dengan rencana kunjungan Anda.</p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                    <label for="date" class="block text-sm font-bold text-gray-700 mb-2">4. Tanggal Kunjungan</label>
                    <input type="date" name="date" id="date" min="{{ now()->format('Y-m-d') }}" required class="block w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500 py-3">
                </div>

                <div>
                    <label for="complaint" class="block text-sm font-bold text-gray-700 mb-2">5. Keluhan Singkat</label>
                    <textarea name="complaint" id="complaint" rows="1" class="block w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500" placeholder="Contoh: Demam, Pusing..."></textarea>
                </div>
            </div>

            <div class="mt-8 flex justify-end pt-6 border-t border-gray-100">
                <a href="{{ route('appointments.index') }}" class="mr-3 px-6 py-3 bg-gray-100 text-gray-700 font-bold rounded-lg hover:bg-gray-200 transition">
                    Batal
                </a>
                <button type="submit" class="px-8 py-3 bg-teal-600 text-white font-bold rounded-lg shadow-lg hover:bg-teal-700 transform transition hover:-translate-y-1">
                    Buat Janji Temu
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function loadDoctors(poliId) {
        const doctorSelect = document.getElementById('doctor_id');
        const scheduleSelect = document.getElementById('schedule_id');
        
        // Reset
        doctorSelect.innerHTML = '<option value="">-- Loading... --</option>';
        doctorSelect.disabled = true;
        scheduleSelect.innerHTML = '<option value="">-- Pilih Jadwal --</option>';
        scheduleSelect.disabled = true;

        if (!poliId) {
            doctorSelect.innerHTML = '<option value="">-- Pilih Dokter --</option>';
            return;
        }

        fetch(`{{ url('/api/polis') }}/${poliId}/doctors`)
            .then(res => res.json())
            .then(data => {
                doctorSelect.innerHTML = '<option value="">-- Pilih Dokter --</option>';
                data.forEach(doctor => {
                    doctorSelect.innerHTML += `<option value="${doctor.id}">${doctor.name}</option>`;
                });
                doctorSelect.disabled = false;
            });
    }

    function loadSchedules(doctorId) {
        const scheduleSelect = document.getElementById('schedule_id');
        
        // Reset
        scheduleSelect.innerHTML = '<option value="">-- Loading... --</option>';
        scheduleSelect.disabled = true;

        if (!doctorId) {
            scheduleSelect.innerHTML = '<option value="">-- Pilih Jadwal --</option>';
            return;
        }

        fetch(`{{ url('/api/doctors') }}/${doctorId}/schedules`)
            .then(res => res.json())
            .then(data => {
                scheduleSelect.innerHTML = '<option value="">-- Pilih Jadwal --</option>';
                if(data.length === 0) {
                     scheduleSelect.innerHTML = '<option value="">Dokter tidak memiliki jadwal</option>';
                } else {
                    data.forEach(schedule => {
                        // Format jam sederhana
                        const start = schedule.start_time.substring(0, 5);
                        scheduleSelect.innerHTML += `<option value="${schedule.id}">${schedule.day} | Pukul ${start} WIB (${schedule.duration_minutes} Menit)</option>`;
                    });
                    scheduleSelect.disabled = false;
                }
            });
    }
</script>
@endsection